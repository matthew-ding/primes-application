package problem10_11_12;
import java.io.*;
import java.util.*;

public class problem12 {
	static ArrayList<Double>[][][] array; //dynamic programming array
	static BackPointer[][][] backList; //list of backpointers
	static String[] keyArray; //array of nonterminals
	
	public static void main(String[] args) throws FileNotFoundException {
		Scanner fin = new Scanner(new File("problem12Grammar.in"));
		fin.useDelimiter(":|\\n| ");
		PGrammar grammar = new PGrammar();
		
		//inputting grammar
		do  {
			try {
				String ruleleft = fin.next().trim();
				String ruleright = fin.next().trim();
				grammar.Add(ruleleft,ruleright, 0);
			}
			catch (Exception e) {
				break;
			}
		} while (fin.hasNextLine());
	    fin.close();
	    
	    //obtaining Probabilistic CFG
	    HashMap<String, HashSet<Derivation>> dictionary = grammar.getGrammar();
	    
	    //setting all rules for within each nonterminal to be equally likely
	    for (String key: dictionary.keySet()) {
	    	double probability=1.0/dictionary.get(key).size();
	    	for (Derivation derivation: dictionary.get(key)) {
	    		grammar.setProbability(key, derivation.getDerivation(), probability);
	    	}
	    }
	    
	    //creating order list of nonterminals for CYK
	    keyArray = problem11.createKeyArray(dictionary);
	    
	    //iteratively computing probabilities
	    for (int i=0; i<10; i++) {
		    Scanner fin2 = new Scanner(new File("problem10.out"));
			while (fin2.hasNext()) {
				String derivation = fin2.next();
				ProbabilityCYK(grammar, dictionary, derivation);
			}
			fin2.close();
			
			RecalculateProbability(grammar);
	    }
	    
	    
	    //Output probabilities
	    PrintWriter out = new PrintWriter(new File("problem12.out"));
	    
	    for (String key: grammar.getGrammar().keySet()) {
			for (Derivation derivation:grammar.getGrammar().get(key)) {
				out.println(key + " " + derivation.getDerivation() + " " + derivation.getProbability());
			}
		}
		out.close();
	}
	
	//recalculates probabilities for each rule after each CYK iteration
	public static void RecalculateProbability(PGrammar Grammar) {
		HashMap<String, HashSet<Derivation>> dictionary = Grammar.getGrammar();
		for (String key: dictionary.keySet()) {
			int total=0; //total occurences of rules with specific key
			for (Derivation derivation: dictionary.get(key)) {
				total+=derivation.getCounter();
			}
			
			if (total!=0) {
				for (Derivation derivation: dictionary.get(key)) {
					int counter = derivation.getCounter();
					derivation.setProbability((double)counter/total);
					derivation.setCounter(0);
				}
			}
		}
	}
	
	//https://en.wikipedia.org/wiki/CYK_algorithm
	public static void ProbabilityCYK(PGrammar Grammar, HashMap<String, HashSet<Derivation>> grammar, String input) {
		if (input.equals("$")) {
			for (Derivation derivation: grammar.get("S")) {
				if (derivation.getDerivation().equals("$")) {
					Grammar.appendCounter("S", "$");
					break;
				}
			}
			return;	
		}
		
		int n = input.length();
		int r = grammar.size();
		array = new ArrayList[n+1][n+1][r+1];
		for (int i=0; i<=n; i++) {
			for (int j=0; j<=n; j++) {
				for (int k=0; k<=r; k++) {
					array[i][j][k]=new ArrayList<Double>();
				}
			}
		}
		
		backList = new BackPointer[n+1][n+1][r+1];
		for (int i=0; i<=n; i++) {
			for (int j=0; j<=n; j++) {
				for (int k=0; k<=r; k++) {
					backList[i][j][k]=new BackPointer();
				}
			}
		}
		
		//maps nonterminal to its integer index in the array
		//created to get O(1) lookup for index number from nonTerminal
		HashMap<String, Integer> keyMap = new HashMap<>();
		for (int i=1; i<=r; i++) {
			keyMap.put(keyArray[i],i);
		}
				
		//considering length 1 substrings
		for (int s=1; s<=n; s++) {
			for (int v=1; v<=r; v++) {
				for (Derivation derived: grammar.get(keyArray[v])) {
					if (derived.derivation.equals(Character.toString(input.charAt(s-1)))) {
						array[1][s][v].add(derived.probability);
					}
				}
			}	
		}
		
		//considering length 2->n substrings
		for (int l=2; l<=n; l++) {
			for (int s=1; s<=n-l+1; s++) {
				for (int p=1; p<=l-1; p++) {
					for (int a=1; a<=r; a++) {
						if (l==n && a!=1) {
							break;
						}
						for (Derivation derived:grammar.get(keyArray[a])) {
							if (derived.derivation.length()==2) {
								char firstChar = derived.derivation.charAt(0);
								char secondChar = derived.derivation.charAt(1);	
								//O(1) lookup of index for given string
								int b = keyMap.get(Character.toString(firstChar));
								int c = keyMap.get(Character.toString(secondChar));	
								
								double prob_splitting = derived.probability; //*array[p][s][b]*array[l-p][s+p][c];
								if (array[p][s][b].size()>0 && array[l-p][s+p][c].size()>0) {
									array[l][s][a].add(prob_splitting);
									backList[l][s][a].Add(p,b,c);
								}
							}
						}
					}
				}
			}
		}
		
		//key: probability, value: arraylist of derivations
		//sorts by descending probability
		TreeMap<Double, ArrayList<ArrayList<Derivation>>> probabilityDerivation = new TreeMap<>();
		
		DerivationList derivObj=new DerivationList(new ArrayList<Derivation>(), "S", 1);
		
		//using backpointers to DFS trace through all parse trees
		generateLeftDerivation(probabilityDerivation, grammar, n,1, 1, input, derivObj);
		
		ArrayList<Derivation> parseTree = chooseParseTree(probabilityDerivation);
		for (Derivation derivation: parseTree) {
			Grammar.appendCounter(derivation.getKey(), derivation.getDerivation());
		}
	}
	
	//Nearly identical method to Problem 11
	//This method stores derivation is ArrayList rather than string
	public static void generateLeftDerivation(TreeMap<Double, ArrayList<ArrayList<Derivation>>> probabilityDerivation, HashMap<String, HashSet<Derivation>> grammar, 
			int l, int s, int a, String input, DerivationList derivObj) {		
		
		if (l==1) {
			//reaching leaf of parse tree (nonterminal to terminal derivation)
			String terminal = Character.toString(input.charAt(s-1));
			derivObj.derivation=derivObj.derivation.replaceFirst(keyArray[a], terminal);
			derivObj.derivationOrder.add(new Derivation(keyArray[a],terminal));
			derivObj.probability*=array[l][s][a].get(0);
			
			//last function call of parse tree
			if (s==input.length()) {
				if (!probabilityDerivation.containsKey(derivObj.probability)) {
					probabilityDerivation.put(derivObj.probability, new ArrayList<ArrayList<Derivation>>());
				}
				
				probabilityDerivation.get(derivObj.probability).add(derivObj.derivationOrder);
			}
		}
		else {
			DerivationList topDerivObj = new DerivationList(derivObj);
			for (int i=0; i< backList[l][s][a].getPointer().size(); i++) {
				if (i>0) {
					derivObj = new DerivationList(topDerivObj);
				}
				
				//probability calculation
				derivObj.probability*=array[l][s][a].get(i);
				
				int p=backList[l][s][a].getPointer(i).get(0);
				int b=backList[l][s][a].getPointer(i).get(1);
				int c=backList[l][s][a].getPointer(i).get(2);
				
				//updating derivation
				derivObj.derivation=derivObj.derivation.replaceFirst(keyArray[a], keyArray[b] + keyArray[c]);
				derivObj.derivationOrder.add(new Derivation(keyArray[a], keyArray[b]+keyArray[c]));
				
				//left terminal derivation
				generateLeftDerivation(probabilityDerivation, grammar, p,s,b, input, derivObj);
				
				//right terminal derivation
				generateLeftDerivation(probabilityDerivation, grammar, l-p, s+p, c, input, derivObj);
			}
		}
	}
	
	//if there are multiple parse trees for a string, we choose one given their relative probabilities
	public static ArrayList<Derivation> chooseParseTree(TreeMap<Double, ArrayList<ArrayList<Derivation>>> probabilityDerivation) {
		double totalProbability=0;
		ArrayList<ArrayList<Derivation>> parseTreeList = new ArrayList<ArrayList<Derivation>>();//list of all possible parse trees
		ArrayList<Double> probabilityList = new ArrayList<>();
		for (double probability: probabilityDerivation.keySet()) {
			for (ArrayList<Derivation> parseTree: probabilityDerivation.get(probability)) {
				parseTreeList.add(parseTree);
				probabilityList.add(probability);
				totalProbability+=probability;
			}
		}
		
		Random rand = new Random();
		double randomNumber = rand.nextDouble()*totalProbability; //generating random number to determine which rule to choose
		double counter=0;
		
		//random rule chosen calculation
		for (int i=0; i<parseTreeList.size();i++) {
			counter+=probabilityList.get(i);
			if (randomNumber<counter) {
				return parseTreeList.get(i);
			}
		}
		return parseTreeList.get(parseTreeList.size()-1);
	}
}



